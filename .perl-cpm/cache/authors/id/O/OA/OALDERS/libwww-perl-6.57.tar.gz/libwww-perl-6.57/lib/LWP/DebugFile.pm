package LWP::DebugFile;

our $VERSION = '6.57';

# legacy stub

1;
