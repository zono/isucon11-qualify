package main

import "github.com/anthonynsimon/bild/cmd"

func main() {
	cmd.Execute()
}
