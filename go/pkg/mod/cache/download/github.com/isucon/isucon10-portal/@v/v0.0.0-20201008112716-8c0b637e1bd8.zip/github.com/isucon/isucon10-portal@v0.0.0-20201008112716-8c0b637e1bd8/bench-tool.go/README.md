# bench-tool.go ISUCON10 benchmarker utilities for Go

See [testcli/main.go](./testcli/main.go) for the details.

## Test how your benchmarker implementation sends a report locally

```
cd ../supervisor
cargo run --bin oneshot path/to/your/benchmarker-bin arg...
```
