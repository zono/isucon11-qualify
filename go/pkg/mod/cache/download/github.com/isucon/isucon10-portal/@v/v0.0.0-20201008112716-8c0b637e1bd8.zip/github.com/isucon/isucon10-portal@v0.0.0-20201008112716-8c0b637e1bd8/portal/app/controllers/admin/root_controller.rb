class Admin::RootController < Admin::ApplicationController
  def index
  end
end
