class Registration::RegistrationController < Registration::ApplicationController
  def index
  end
end
