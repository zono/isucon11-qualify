class Api::Registration::ApplicationController < Api::ApplicationController
end
