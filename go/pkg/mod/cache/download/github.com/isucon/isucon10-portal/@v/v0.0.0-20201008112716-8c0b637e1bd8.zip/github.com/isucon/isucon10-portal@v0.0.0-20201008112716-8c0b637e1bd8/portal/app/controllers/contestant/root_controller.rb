class Contestant::RootController < Contestant::ApplicationController
  def index
  end
end
