require "isux_hako_deployment/version"

module IsuxHakoDeployment
  class Error < StandardError; end
  # Your code goes here...
end
