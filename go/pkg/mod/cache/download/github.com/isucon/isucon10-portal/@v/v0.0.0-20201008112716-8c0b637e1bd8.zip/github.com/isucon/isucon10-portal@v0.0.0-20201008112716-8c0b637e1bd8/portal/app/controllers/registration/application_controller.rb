class Registration::ApplicationController < ApplicationController
end
