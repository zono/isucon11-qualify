import { fetchAndUpdateNavbarSession } from "../NavbarSession";
fetchAndUpdateNavbarSession();
