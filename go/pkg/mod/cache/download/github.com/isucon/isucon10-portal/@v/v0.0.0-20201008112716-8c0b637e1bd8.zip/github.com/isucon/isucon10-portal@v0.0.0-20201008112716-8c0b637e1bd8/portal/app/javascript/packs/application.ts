import "./application.scss";
import "../sentry.js";

// TODO: import 'raven';

import * as Rails from "@rails/ujs";
Rails.start();
