class RootController < ApplicationController
  def index
  end
end
