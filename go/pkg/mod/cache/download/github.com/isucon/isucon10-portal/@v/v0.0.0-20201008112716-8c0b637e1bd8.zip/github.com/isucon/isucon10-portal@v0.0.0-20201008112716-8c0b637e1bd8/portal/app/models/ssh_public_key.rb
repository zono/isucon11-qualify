class SshPublicKey < ApplicationRecord
  belongs_to :contestant
end
