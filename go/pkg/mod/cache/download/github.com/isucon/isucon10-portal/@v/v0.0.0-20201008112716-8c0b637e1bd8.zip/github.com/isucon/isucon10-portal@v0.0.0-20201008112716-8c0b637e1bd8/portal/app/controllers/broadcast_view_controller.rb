class BroadcastViewController < ApplicationController
  def index
  end
end
